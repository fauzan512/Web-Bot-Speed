import { useState } from "react";
import { Zap, KeyRound, Eye, EyeOff, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getBalance } from "@/lib/heroApi";

interface LoginProps {
  onLogin: (apiKey: string) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [apiKey, setApiKey] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKey.trim()) return;
    setLoading(true);
    setError("");
    try {
      const json = await getBalance(apiKey.trim());
      if (json.success) {
        localStorage.setItem("hero_api_key", apiKey.trim());
        onLogin(apiKey.trim());
      } else {
        setError(json.error || "API key tidak valid");
      }
    } catch {
      setError("Gagal terhubung ke hero-sms.com");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen bg-[#0a0a0a] flex items-center justify-center font-mono">
      <div className="w-full max-w-sm px-4">
        <div className="bg-[#111] border border-[#1e1e1e] rounded-xl p-8 space-y-6">
          <div className="flex flex-col items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
              <Zap className="w-6 h-6 text-emerald-400" />
            </div>
            <div className="text-center">
              <h1 className="text-lg font-bold text-white tracking-wide">HERO-SMS BOT</h1>
              <p className="text-[11px] text-zinc-500 mt-0.5">WhatsApp OTP · Mexico +52 · $1.50/unit</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] text-zinc-500 uppercase tracking-widest flex items-center gap-1.5">
                <KeyRound className="w-3 h-3" />
                API Key
              </label>
              <div className="relative">
                <Input
                  type={show ? "text" : "password"}
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Masukkan API key hero-sms.com"
                  className="bg-[#0d0d0d] border-[#2a2a2a] text-white placeholder:text-zinc-700 text-[13px] pr-9 font-mono focus:border-emerald-700 focus:ring-0"
                  data-testid="input-api-key"
                  autoComplete="off"
                />
                <button
                  type="button"
                  onClick={() => setShow(!show)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400"
                >
                  {show ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {error && (
              <div
                data-testid="text-login-error"
                className="text-[11px] text-red-400 bg-red-950/20 border border-red-900/30 rounded-md px-3 py-2"
              >
                {error}
              </div>
            )}

            <Button
              type="submit"
              disabled={loading || !apiKey.trim()}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold h-10 gap-2 text-sm"
              data-testid="button-login"
            >
              {loading ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Verifikasi...</>
              ) : (
                <><Zap className="w-4 h-4" /> Masuk</>
              )}
            </Button>
          </form>

          <p className="text-[10px] text-zinc-700 text-center">
            API key dari akun{" "}
            <a
              href="https://hero-sms.com"
              target="_blank"
              rel="noreferrer"
              className="text-zinc-500 hover:text-zinc-300 underline underline-offset-2"
            >
              hero-sms.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
