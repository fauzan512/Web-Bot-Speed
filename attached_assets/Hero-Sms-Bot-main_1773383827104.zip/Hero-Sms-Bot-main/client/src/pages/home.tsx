import { useState, useRef, useCallback, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getBalance, getPrices, buyNumber, getStatus, cancelNumber as cancelApi } from "@/lib/heroApi";
import {
  Zap, StopCircle, RefreshCw, CheckCircle2, XCircle,
  Clock, Loader2, LogOut, Copy, Check, Ban, MessageSquare,
  ShoppingCart, Minus, Plus, Gauge,
} from "lucide-react";

// ─── Sound ────────────────────────────────────────────────────────────────────

function playSuccessSound() {
  try {
    const ctx = new AudioContext();
    // Two-note chime: C6 → E6
    const notes = [1046.5, 1318.5];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.value = freq;
      const start = ctx.currentTime + i * 0.15;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.25, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.45);
      osc.start(start);
      osc.stop(start + 0.45);
    });
  } catch {}
}

// ─── Types ────────────────────────────────────────────────────────────────────

type Mode = "mexico" | "philippines";

type LogEntry = {
  id: string;
  timestamp: Date;
  type: "success" | "retry" | "error" | "stop" | "info" | "otp";
  message: string;
};

type PurchasedNumber = {
  orderId: string;
  phone: string;
  mode: Mode;
  purchasedAt: Date;
  otp: string | null;
  status: "waiting" | "received" | "cancelled";
  cancelLoading: boolean;
};

type StoredNumber = Omit<PurchasedNumber, "purchasedAt" | "cancelLoading"> & {
  purchasedAt: string;
};

// ─── Constants ────────────────────────────────────────────────────────────────

const CANCEL_DELAY_MS = 2 * 60 * 1000;
const STORAGE_KEY = "hero_orders";
const PH_MAX_PRICE = 0.17;
const PH_COUNTRY = "4";
const MX_COUNTRY = "54";

// ─── LocalStorage helpers ─────────────────────────────────────────────────────

function saveOrders(orders: PurchasedNumber[]) {
  const data: StoredNumber[] = orders.map((n) => ({
    orderId: n.orderId, phone: n.phone, mode: n.mode,
    purchasedAt: n.purchasedAt.toISOString(), otp: n.otp, status: n.status,
  }));
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function loadOrders(): PurchasedNumber[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: StoredNumber[] = JSON.parse(raw);
    return parsed.map((n) => ({ ...n, purchasedAt: new Date(n.purchasedAt), cancelLoading: false }));
  } catch { return []; }
}

// ─── Utilities ────────────────────────────────────────────────────────────────

function stripCountryCode(phone: string, code: string): string {
  const p = phone.replace(/\D/g, "");
  return p.startsWith(code) ? p.slice(code.length) : p;
}

// ─── CopyBtn ──────────────────────────────────────────────────────────────────

function CopyBtn({ text, testId }: { text: string; testId?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => navigator.clipboard.writeText(text).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1500); })}
      data-testid={testId}
      className="p-1.5 rounded-md text-zinc-600 hover:text-zinc-200 hover:bg-white/5 active:scale-95 transition-all"
      title="Salin"
    >
      {copied
        ? <Check className="w-3.5 h-3.5 text-emerald-400" />
        : <Copy className="w-3.5 h-3.5" />}
    </button>
  );
}

// ─── NumberCard ───────────────────────────────────────────────────────────────

function NumberCard({ entry, apiKey, onOtp, onCancel, onLog }: {
  entry: PurchasedNumber; apiKey: string;
  onOtp: (id: string, code: string) => void;
  onCancel: (id: string) => void;
  onLog: (type: LogEntry["type"], msg: string) => void;
}) {
  const [elapsed, setElapsed] = useState(() => Date.now() - entry.purchasedAt.getTime());

  useEffect(() => {
    const t = setInterval(() => setElapsed(Date.now() - entry.purchasedAt.getTime()), 1000);
    return () => clearInterval(t);
  }, [entry.purchasedAt]);

  useEffect(() => {
    if (entry.status !== "waiting") return;
    const poll = setInterval(async () => {
      try {
        const json = await getStatus(apiKey, entry.orderId);
        const s: string = json.status ?? "";
        if (s.startsWith("STATUS_OK:")) {
          const code = s.split(":")[1];
          onOtp(entry.orderId, code);
          onLog("otp", `OTP ${entry.phone}: ${code}`);
          clearInterval(poll);
        } else if (s === "STATUS_CANCEL" || s === "STATUS_BANNED") {
          onOtp(entry.orderId, "CANCELLED");
          clearInterval(poll);
        }
      } catch {}
    }, 5000);
    return () => clearInterval(poll);
  }, [entry.orderId, entry.status, entry.phone, apiKey, onOtp, onLog]);

  const canCancel = elapsed >= CANCEL_DELAY_MS && entry.status === "waiting" && !entry.cancelLoading;
  const secsLeft = Math.max(0, Math.ceil((CANCEL_DELAY_MS - elapsed) / 1000));
  const countryCode = entry.mode === "philippines" ? "63" : "52";
  const localNum = stripCountryCode(entry.phone, countryCode);

  return (
    <div
      data-testid={`card-number-${entry.orderId}`}
      className={`rounded-xl border p-4 space-y-3 transition-all ${
        entry.status === "received" ? "border-emerald-800/50 bg-emerald-950/10" :
        entry.status === "cancelled" ? "border-zinc-800/40 bg-zinc-900/20 opacity-50" :
        "border-zinc-800 bg-zinc-900/40"
      }`}
    >
      {/* Phone row */}
      <div className="flex items-center gap-2">
        {entry.status === "received" && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
        {entry.status === "cancelled" && <XCircle className="w-4 h-4 text-zinc-600 shrink-0" />}
        {entry.status === "waiting" && <Loader2 className="w-4 h-4 text-yellow-400 shrink-0 animate-spin" />}
        <span className="flex-1 text-[13px] font-semibold text-white truncate">{entry.phone}</span>
        <CopyBtn text={localNum} testId={`copy-phone-${entry.orderId}`} />
      </div>

      {/* OTP row */}
      {entry.otp && entry.status === "received" && (
        <div className="flex items-center justify-between bg-emerald-950/50 border border-emerald-800/40 rounded-lg px-3 py-2.5">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span
              data-testid={`otp-code-${entry.orderId}`}
              className="text-2xl font-bold text-emerald-300 tracking-[0.25em]"
            >
              {entry.otp}
            </span>
          </div>
          <CopyBtn text={entry.otp} testId={`copy-otp-${entry.orderId}`} />
        </div>
      )}

      {/* Footer row */}
      <div className="flex items-center justify-between">
        <span className="text-[11px] text-zinc-600">#{entry.orderId}</span>
        {entry.status === "waiting" && (
          <button
            disabled={!canCancel}
            onClick={() => onCancel(entry.orderId)}
            data-testid={`button-cancel-${entry.orderId}`}
            className={`flex items-center gap-1 text-[11px] px-2 py-1 rounded-md transition-colors ${
              canCancel ? "text-red-400 hover:bg-red-950/30" : "text-zinc-700 cursor-not-allowed"
            }`}
          >
            {entry.cancelLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Ban className="w-3 h-3" />}
            {canCancel ? "Cancel & kembalikan saldo" : `Cancel ${secsLeft}d`}
          </button>
        )}
        {entry.status === "cancelled" && (
          <span className="text-[11px] text-zinc-600">Dibatalkan · saldo kembali</span>
        )}
      </div>
    </div>
  );
}

// ─── Home ─────────────────────────────────────────────────────────────────────

interface HomeProps { apiKey: string; onLogout: () => void; }

export default function Home({ apiKey, onLogout }: HomeProps) {
  const qc = useQueryClient();
  const [mode, setMode] = useState<Mode>("mexico");
  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showLog, setShowLog] = useState(false);
  const [purchased, setPurchased] = useState<PurchasedNumber[]>(() => loadOrders());
  const [retryCount, setRetryCount] = useState(0);
  const [buyCount, setBuyCount] = useState(0);
  const [phQty, setPhQty] = useState(1);
  const [mxParallel, setMxParallel] = useState(3);
  const [mxDelay, setMxDelay] = useState(500);
  const [phDelay, setPhDelay] = useState(500);
  const stopRef = useRef(false);

  useEffect(() => { saveOrders(purchased); }, [purchased]);

  const { data: balanceData, refetch: refetchBalance } = useQuery<{ success: boolean; balance?: number; error?: string }>({
    queryKey: ["/api/balance", apiKey],
    queryFn: () => getBalance(apiKey),
    refetchInterval: isRunning ? 4000 : 20000,
  });

  const { data: phPrice, refetch: refetchPhPrice } = useQuery<{ success: boolean; cost: number | null; count: number }>({
    queryKey: ["/api/prices/ph", apiKey],
    queryFn: () => getPrices(apiKey, "wa", PH_COUNTRY),
    refetchInterval: mode === "philippines" ? 30000 : false,
    enabled: mode === "philippines",
  });

  const addLog = useCallback((type: LogEntry["type"], message: string) => {
    setLogs((prev) => {
      const next = [...prev, { id: Math.random().toString(36).slice(2), timestamp: new Date(), type, message }];
      return next.length > 300 ? next.slice(next.length - 300) : next;
    });
  }, []);

  const handleOtp = useCallback((orderId: string, code: string) => {
    if (code !== "CANCELLED") playSuccessSound();
    setPurchased((prev) => prev.map((n) => n.orderId === orderId
      ? { ...n, otp: code === "CANCELLED" ? null : code, status: code === "CANCELLED" ? "cancelled" : "received" }
      : n));
  }, []);

  const handleCancel = useCallback(async (orderId: string) => {
    setPurchased((prev) => prev.map((n) => n.orderId === orderId ? { ...n, cancelLoading: true } : n));
    try {
      const json = await cancelApi(apiKey, orderId);
      if (json.success) {
        setPurchased((prev) => prev.map((n) => n.orderId === orderId ? { ...n, status: "cancelled", cancelLoading: false } : n));
        addLog("stop", `#${orderId} dibatalkan — saldo dikembalikan`);
        qc.invalidateQueries({ queryKey: ["/api/balance", apiKey] });
        refetchBalance();
      } else {
        setPurchased((prev) => prev.map((n) => n.orderId === orderId ? { ...n, cancelLoading: false } : n));
        addLog("error", `Gagal cancel #${orderId}`);
      }
    } catch {
      setPurchased((prev) => prev.map((n) => n.orderId === orderId ? { ...n, cancelLoading: false } : n));
    }
  }, [addLog, apiKey, qc, refetchBalance]);

  // Mexico: parallel spam-buy until balance runs out
  const runMexicoLoop = useCallback(async () => {
    stopRef.current = false;
    setIsRunning(true);
    setBuyCount(0);
    setRetryCount(0);
    const parallel = mxParallel;
    addLog("info", `Bot Mexico dimulai — WA +52 maks $2.00 · ${parallel} paralel`);
    let localBuy = 0, localRetry = 0, iterCount = 0;

    // Initial balance check — direct browser call
    const initBalJson = await getBalance(apiKey);
    if (!initBalJson.success || (initBalJson.balance ?? 0) < 2.00) {
      addLog("stop", `Saldo tidak cukup — butuh min $2.00 (ada: $${initBalJson.balance?.toFixed(2) ?? "0"})`);
      setIsRunning(false);
      return;
    }
    qc.invalidateQueries({ queryKey: ["/api/balance", apiKey] });

    const doOneBuy = () =>
      buyNumber(apiKey, { country: MX_COUNTRY, service: "wa", maxPrice: "2.00" });

    while (!stopRef.current) {
      iterCount++;

      // Re-check balance every 10 rounds
      if (iterCount % 10 === 0) {
        const balJson = await getBalance(apiKey);
        qc.invalidateQueries({ queryKey: ["/api/balance", apiKey] });
        if (!balJson.success || (balJson.balance ?? 0) < 2.00) {
          addLog("stop", `Saldo tidak cukup ($${balJson.balance?.toFixed(2) ?? "0"}) — berhenti`);
          break;
        }
      }

      // Fire `parallel` requests simultaneously
      const results = await Promise.all(Array.from({ length: parallel }, doOneBuy));

      let roundBought = 0;
      let gotNoMoney = false;

      for (const json of results) {
        if (json.success) {
          localBuy++; roundBought++;
          setBuyCount(localBuy);
          setRetryCount(0); localRetry = 0;
          playSuccessSound();
          addLog("success", `Beli: ${json.phone} (#${json.orderId})`);
          setPurchased((prev) => [{
            orderId: json.orderId!, phone: json.phone!, mode: "mexico",
            purchasedAt: new Date(), otp: null, status: "waiting", cancelLoading: false,
          }, ...prev]);
        } else if (json.error === "NO_MONEY") {
          gotNoMoney = true;
        }
      }

      if (gotNoMoney) {
        addLog("stop", "Saldo habis — berhenti");
        qc.invalidateQueries({ queryKey: ["/api/balance", apiKey] });
        break;
      }

      if (roundBought === 0) {
        localRetry += parallel;
        setRetryCount(localRetry);
        addLog("retry", `NO_NUMBERS (x${parallel}) — retry #${localRetry}`);
        await new Promise((r) => setTimeout(r, mxDelay));
      }
      // No pause on success — fire next round immediately
    }

    setIsRunning(false);
    stopRef.current = false;
    qc.invalidateQueries({ queryKey: ["/api/balance", apiKey] });
    refetchBalance();
    addLog("info", `Selesai. Total beli: ${localBuy} nomor`);
  }, [addLog, apiKey, mxParallel, mxDelay, qc, refetchBalance]);

  // Philippines: buy exact qty, max $0.17
  const runPhilippinesLoop = useCallback(async (qty: number) => {
    stopRef.current = false;
    setIsRunning(true);
    setBuyCount(0);
    setRetryCount(0);
    addLog("info", `Bot Filipina dimulai — WA +63, target ${qty} nomor, maks $${PH_MAX_PRICE}`);
    let localBuy = 0, localRetry = 0;

    while (!stopRef.current && localBuy < qty) {
      const balJson = await getBalance(apiKey);
      if (!balJson.success || (balJson.balance !== undefined && balJson.balance < 0.15)) {
        addLog("stop", `Saldo tidak cukup ($${balJson.balance?.toFixed(2) ?? "0"}) — berhenti`);
        break;
      }
      qc.invalidateQueries({ queryKey: ["/api/balance", apiKey] });

      const json = await buyNumber(apiKey, { country: PH_COUNTRY, service: "wa", maxPrice: String(PH_MAX_PRICE) });

      if (json.success && json.orderId && json.phone) {
        localBuy++; localRetry = 0;
        setBuyCount(localBuy); setRetryCount(0);
        addLog("success", `[${localBuy}/${qty}] Beli: ${json.phone} (#${json.orderId})`);
        setPurchased((prev) => [{ orderId: json.orderId!, phone: json.phone!, mode: "philippines", purchasedAt: new Date(), otp: null, status: "waiting", cancelLoading: false }, ...prev]);
        if (localBuy >= qty) {
          addLog("info", `Target ${qty} nomor tercapai!`);
          break;
        }
      } else if (json.error === "NO_NUMBERS") {
        localRetry++;
        setRetryCount(localRetry);
        addLog("retry", `Nomor tidak tersedia ≤$${PH_MAX_PRICE}, retry #${localRetry}...`);
        await new Promise((r) => setTimeout(r, phDelay));
        continue;
      } else if (json.error === "NO_MONEY") {
        addLog("stop", "Saldo habis — berhenti");
        break;
      } else {
        addLog("error", `Error: ${json.error ?? "unknown"}`);
        await new Promise((r) => setTimeout(r, phDelay));
        continue;
      }
      await new Promise((r) => setTimeout(r, 100));
    }

    setIsRunning(false);
    stopRef.current = false;
    qc.invalidateQueries({ queryKey: ["/api/balance", apiKey] });
    refetchBalance();
    if (!stopRef.current) addLog("info", `Selesai. Beli: ${localBuy}/${qty} nomor`);
  }, [addLog, apiKey, phDelay, qc, refetchBalance]);

  const handleStop = () => {
    stopRef.current = true;
    addLog("stop", "Bot dihentikan");
  };

  const handleLogout = () => {
    stopRef.current = true;
    localStorage.removeItem("hero_api_key");
    onLogout();
  };

  const waiting = purchased.filter((p) => p.status === "waiting").length;
  const received = purchased.filter((p) => p.status === "received").length;
  const fmtTime = (d: Date) => d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const logColor = (t: LogEntry["type"]) => ({ success: "text-emerald-400", retry: "text-yellow-400", error: "text-red-400", stop: "text-orange-400", otp: "text-purple-400 font-bold", info: "text-blue-400" }[t]);

  const phCostDisplay = phPrice?.cost != null ? `$${phPrice.cost.toFixed(2)}` : "--";
  const phPriceAboveLimit = phPrice?.cost != null && phPrice.cost > PH_MAX_PRICE;
  const canAffordPh = (balanceData?.balance ?? 0) >= (phPrice?.cost ?? 0.15) * phQty;
  const totalPhCost = ((phPrice?.cost ?? 0.15) * phQty).toFixed(2);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-mono flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-[#0a0a0a]/95 backdrop-blur border-b border-zinc-800/60 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
            <Zap className="w-3 h-3 text-emerald-400" />
          </div>
          <span className="text-sm font-bold text-white">HERO-SMS</span>
          {isRunning && (
            <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 rounded px-1.5 py-0.5">
              <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" /> RUN
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span data-testid="text-balance" className="text-base font-bold text-white">
              {balanceData?.success ? `$${balanceData.balance?.toFixed(2)}` : "--"}
            </span>
            <button onClick={() => refetchBalance()} data-testid="button-refresh-balance" className="text-zinc-700 hover:text-zinc-400 transition-colors">
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>
          <button onClick={handleLogout} data-testid="button-logout" className="text-zinc-600 hover:text-red-400 transition-colors">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex-1 max-w-lg mx-auto w-full px-4 py-5 space-y-4">

        {/* Mode Switch */}
        <div className="flex gap-1 p-1 bg-zinc-900 border border-zinc-800 rounded-xl">
          <button
            onClick={() => { if (!isRunning) setMode("mexico"); }}
            data-testid="button-mode-mexico"
            disabled={isRunning}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[13px] font-semibold transition-all ${
              mode === "mexico"
                ? "bg-zinc-700 text-white shadow"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            🇲🇽 Mexico Auto
          </button>
          <button
            onClick={() => { if (!isRunning) setMode("philippines"); }}
            data-testid="button-mode-philippines"
            disabled={isRunning}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[13px] font-semibold transition-all ${
              mode === "philippines"
                ? "bg-zinc-700 text-white shadow"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            🇵🇭 Filipina Custom
          </button>
        </div>

        {/* Mode Info Card */}
        {mode === "mexico" ? (
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl px-4 py-3 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[12px] text-zinc-400 font-semibold">WhatsApp OTP · Mexico +52</p>
                <p className="text-[11px] text-zinc-600 mt-0.5">Spam beli otomatis sampai saldo habis</p>
              </div>
              <span className="text-lg font-bold text-white">≤$2.00</span>
            </div>
            {/* Race / parallel setting */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-1.5">
                <Gauge className="w-3 h-3 text-zinc-500" />
                <p className="text-[10px] text-zinc-500 uppercase tracking-widest">Race Paralel</p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setMxParallel((v) => Math.max(1, v - 1))}
                  disabled={isRunning || mxParallel <= 1}
                  data-testid="button-parallel-minus"
                  className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-white hover:bg-zinc-700 disabled:opacity-40 transition-colors"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 flex flex-col items-center">
                  <span data-testid="text-parallel" className="text-2xl font-bold text-white leading-none">{mxParallel}</span>
                  <span className="text-[9px] text-zinc-600 mt-0.5">request sekaligus</span>
                </div>
                <button
                  onClick={() => setMxParallel((v) => Math.min(10, v + 1))}
                  disabled={isRunning || mxParallel >= 10}
                  data-testid="button-parallel-plus"
                  className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-white hover:bg-zinc-700 disabled:opacity-40 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 text-right">
                  <p className="text-[10px] text-zinc-600">Max paralel</p>
                  <p className="text-sm font-bold text-zinc-400">10</p>
                </div>
              </div>
              {/* Visual bar */}
              <div className="flex gap-1">
                {Array.from({ length: 10 }, (_, i) => (
                  <div
                    key={i}
                    className={`flex-1 h-1 rounded-full transition-colors ${
                      i < mxParallel ? "bg-emerald-500" : "bg-zinc-800"
                    }`}
                  />
                ))}
              </div>
            </div>
            {/* Delay retry setting */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3 h-3 text-zinc-500" />
                <p className="text-[10px] text-zinc-500 uppercase tracking-widest">Delay Retry</p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setMxDelay((v) => Math.max(100, v - 100))}
                  disabled={isRunning || mxDelay <= 100}
                  data-testid="button-mxdelay-minus"
                  className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-white hover:bg-zinc-700 disabled:opacity-40 transition-colors"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 flex flex-col items-center">
                  <span data-testid="text-mxdelay" className="text-2xl font-bold text-white leading-none">
                    {mxDelay >= 1000 ? `${mxDelay / 1000}s` : `${mxDelay}`}
                  </span>
                  <span className="text-[9px] text-zinc-600 mt-0.5">{mxDelay >= 1000 ? "detik" : "ms"} antar retry</span>
                </div>
                <button
                  onClick={() => setMxDelay((v) => Math.min(5000, v + 100))}
                  disabled={isRunning || mxDelay >= 5000}
                  data-testid="button-mxdelay-plus"
                  className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-white hover:bg-zinc-700 disabled:opacity-40 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 text-right">
                  <p className="text-[10px] text-zinc-600">Default</p>
                  <p className="text-sm font-bold text-zinc-400">500ms</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl px-4 py-3 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[12px] text-zinc-400 font-semibold">WhatsApp OTP · Filipina +63</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className={`text-[11px] font-bold ${phPriceAboveLimit ? "text-yellow-400" : "text-emerald-400"}`}>
                    {phCostDisplay}/nomor
                  </span>
                  {phPrice?.count !== undefined && (
                    <span className="text-[10px] text-zinc-600">{phPrice.count} tersedia</span>
                  )}
                  <button onClick={() => refetchPhPrice()} className="text-zinc-700 hover:text-zinc-400">
                    <RefreshCw className="w-2.5 h-2.5" />
                  </button>
                </div>
                {phPriceAboveLimit && (
                  <p className="text-[10px] text-yellow-500 mt-0.5">Harga di atas $0.17 saat ini — bot akan retry terus sampai harga turun atau distop</p>
                )}
              </div>
              <span className="text-[11px] text-zinc-600 text-right">maks<br /><span className="text-zinc-400 font-bold text-sm">$0.17</span></span>
            </div>

            {/* Quantity picker */}
            <div className="space-y-1">
              <p className="text-[10px] text-zinc-500 uppercase tracking-widest">Jumlah Order</p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setPhQty((v) => Math.max(1, v - 1))}
                  disabled={isRunning || phQty <= 1}
                  className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-white hover:bg-zinc-700 disabled:opacity-40 transition-colors"
                  data-testid="button-qty-minus"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <input
                  type="number"
                  min={1}
                  max={99}
                  value={phQty}
                  onChange={(e) => setPhQty(Math.max(1, Math.min(99, parseInt(e.target.value) || 1)))}
                  disabled={isRunning}
                  className="w-16 text-center bg-zinc-800 border border-zinc-700 rounded-lg h-9 text-white font-bold text-base focus:outline-none focus:border-zinc-500"
                  data-testid="input-qty"
                />
                <button
                  onClick={() => setPhQty((v) => Math.min(99, v + 1))}
                  disabled={isRunning || phQty >= 99}
                  className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-white hover:bg-zinc-700 disabled:opacity-40 transition-colors"
                  data-testid="button-qty-plus"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 text-right">
                  <p className="text-[10px] text-zinc-600">Estimasi total</p>
                  <p className={`text-sm font-bold ${canAffordPh ? "text-white" : "text-red-400"}`}>
                    ${totalPhCost}
                    {!canAffordPh && <span className="text-[10px] font-normal ml-1">(saldo kurang)</span>}
                  </p>
                </div>
              </div>
            </div>
            {/* Delay retry setting */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3 h-3 text-zinc-500" />
                <p className="text-[10px] text-zinc-500 uppercase tracking-widest">Delay Retry</p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setPhDelay((v) => Math.max(100, v - 100))}
                  disabled={isRunning || phDelay <= 100}
                  data-testid="button-phdelay-minus"
                  className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-white hover:bg-zinc-700 disabled:opacity-40 transition-colors"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 flex flex-col items-center">
                  <span data-testid="text-phdelay" className="text-2xl font-bold text-white leading-none">
                    {phDelay >= 1000 ? `${phDelay / 1000}s` : `${phDelay}`}
                  </span>
                  <span className="text-[9px] text-zinc-600 mt-0.5">{phDelay >= 1000 ? "detik" : "ms"} antar retry</span>
                </div>
                <button
                  onClick={() => setPhDelay((v) => Math.min(5000, v + 100))}
                  disabled={isRunning || phDelay >= 5000}
                  data-testid="button-phdelay-plus"
                  className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-white hover:bg-zinc-700 disabled:opacity-40 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 text-right">
                  <p className="text-[10px] text-zinc-600">Default</p>
                  <p className="text-sm font-bold text-zinc-400">500ms</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 text-center">
          {[
            { label: mode === "philippines" ? `Dibeli / ${isRunning ? phQty : "—"}` : "Dibeli", val: buyCount, color: "text-emerald-400" },
            { label: "OTP Masuk", val: received, color: "text-purple-400" },
            { label: "Menunggu", val: waiting, color: "text-yellow-400" },
          ].map(({ label, val, color }) => (
            <div key={label} className="bg-zinc-900/50 border border-zinc-800 rounded-xl py-2.5 px-1">
              <div className={`text-xl font-bold ${color}`}>{val}</div>
              <div className="text-[10px] text-zinc-500 mt-0.5 leading-tight">{label}</div>
            </div>
          ))}
        </div>

        {/* Start / Stop Button */}
        {!isRunning ? (
          <button
            onClick={() => mode === "mexico" ? runMexicoLoop() : runPhilippinesLoop(phQty)}
            data-testid="button-start"
            className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl h-12 transition-all active:scale-[0.98]"
          >
            {mode === "mexico"
              ? <><Zap className="w-4 h-4" /> MULAI BOT MEXICO</>
              : <><ShoppingCart className="w-4 h-4" /> ORDER {phQty} NOMOR FILIPINA</>
            }
          </button>
        ) : (
          <button
            onClick={handleStop}
            data-testid="button-stop"
            className="w-full flex items-center justify-center gap-2 bg-red-700 hover:bg-red-600 text-white font-bold text-sm rounded-xl h-12 transition-all active:scale-[0.98]"
          >
            <StopCircle className="w-4 h-4" />
            {mode === "mexico" ? "STOP BOT" : `STOP (${buyCount}/${phQty} terbeli)`}
          </button>
        )}

        {/* Number Cards */}
        {purchased.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-zinc-500 uppercase tracking-widest">Semua Nomor ({purchased.length})</span>
              <button
                onClick={() => { setPurchased([]); localStorage.removeItem(STORAGE_KEY); }}
                data-testid="button-clear-orders"
                className="text-[11px] text-zinc-700 hover:text-red-400 transition-colors"
              >
                Hapus semua
              </button>
            </div>
            {purchased.map((n) => (
              <NumberCard key={n.orderId} entry={n} apiKey={apiKey} onOtp={handleOtp} onCancel={handleCancel} onLog={addLog} />
            ))}
          </div>
        )}

        {/* Log (collapsible) */}
        {logs.length > 0 && (
          <div className="border border-zinc-800 rounded-xl overflow-hidden">
            <button
              onClick={() => setShowLog((v) => !v)}
              className="w-full flex items-center justify-between px-4 py-2.5 bg-zinc-900/50 text-[11px] text-zinc-500 hover:text-zinc-300 transition-colors"
              data-testid="button-toggle-log"
            >
              <span className="uppercase tracking-widest">Log ({logs.length})</span>
              <span>{showLog ? "▲ Tutup" : "▼ Buka"}</span>
            </button>
            {showLog && (
              <div className="max-h-52 overflow-y-auto px-3 py-2 space-y-0.5 bg-[#0d0d0d]">
                {[...logs].reverse().map((log) => (
                  <div key={log.id} className="flex items-start gap-2 text-[11px] py-0.5" data-testid={`log-entry-${log.id}`}>
                    <span className="text-zinc-700 shrink-0 tabular-nums">{fmtTime(log.timestamp)}</span>
                    <span className={logColor(log.type)}>{log.message}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
