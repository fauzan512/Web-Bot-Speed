const HERO_BASE = "https://hero-sms.com/stubs/handler_api.php";

// ─── Race: server proxy vs CORS proxy — fastest wins ─────────────────────────

async function heroRace(
  serverPath: string,
  serverInit: RequestInit,
  directParams: Record<string, string> & { api_key: string }
): Promise<{ source: "server"; json: any } | { source: "direct"; text: string }> {
  type Result = { source: "server"; json: any } | { source: "direct"; text: string };

  const serverTask: Promise<Result | null> = (async () => {
    try {
      const res = await fetch(serverPath, { ...serverInit, signal: AbortSignal.timeout(7000) });
      const json = await res.json();
      if (json?.error === "CF_BLOCKED") return null;
      return { source: "server" as const, json };
    } catch {
      return null;
    }
  })();

  const directTask: Promise<Result | null> = (async () => {
    try {
      const url = new URL(HERO_BASE);
      for (const [k, v] of Object.entries(directParams)) url.searchParams.set(k, v);
      const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url.toString())}`;
      const res = await fetch(proxyUrl, { signal: AbortSignal.timeout(7000) });
      const text = (await res.text()).trim();
      if (!text || text.startsWith("{\"error\"") || text.includes("<html") || text.includes("<!DOCTYPE")) return null;
      return { source: "direct" as const, text };
    } catch {
      return null;
    }
  })();

  // Race: whichever returns a non-null result first wins
  return new Promise((resolve, reject) => {
    let settled = false;
    let doneCount = 0;

    const tryResolve = (r: Result | null) => {
      doneCount++;
      if (!settled && r !== null) {
        settled = true;
        resolve(r);
      } else if (doneCount === 2 && !settled) {
        reject(new Error("Semua sumber gagal"));
      }
    };

    serverTask.then(tryResolve).catch(() => tryResolve(null));
    directTask.then(tryResolve).catch(() => tryResolve(null));
  });
}

// ─── Public API ───────────────────────────────────────────────────────────────

export async function getBalance(apiKey: string): Promise<{ success: boolean; balance?: number; error?: string }> {
  try {
    const result = await heroRace(
      `/api/balance`,
      { headers: { "x-api-key": apiKey } },
      { api_key: apiKey, action: "getBalance" }
    );
    if (result.source === "server") return result.json;
    const text = result.text;
    if (text.startsWith("ACCESS_BALANCE:")) return { success: true, balance: parseFloat(text.split(":")[1]) };
    if (text === "BAD_KEY") return { success: false, error: "BAD_KEY" };
    return { success: false, error: text };
  } catch {
    return { success: false, error: "Tidak dapat terhubung ke hero-sms.com" };
  }
}

export async function getPrices(apiKey: string, service: string, country: string): Promise<{ success: boolean; cost: number | null; count: number }> {
  try {
    const result = await heroRace(
      `/api/prices?service=${service}&country=${country}`,
      { headers: { "x-api-key": apiKey } },
      { api_key: apiKey, action: "getPrices", service, country }
    );
    if (result.source === "server") return result.json;
    const parsed = JSON.parse(result.text);
    const info = parsed?.[country]?.[service];
    return { success: true, cost: info?.cost ?? null, count: info?.count ?? 0 };
  } catch {
    return { success: false, cost: null, count: 0 };
  }
}

export async function buyNumber(
  apiKey: string,
  opts: { country: string; service: string; maxPrice?: string; operator?: string }
): Promise<{ success: boolean; orderId?: string; phone?: string; error?: string }> {
  try {
    const directParams: Record<string, string> = {
      api_key: apiKey,
      action: "getNumber",
      service: opts.service ?? "wa",
      country: opts.country,
      operator: opts.operator ?? "0",
    };
    if (opts.maxPrice) directParams.maxPrice = opts.maxPrice;

    const result = await heroRace(
      "/api/buy",
      {
        method: "POST",
        headers: { "x-api-key": apiKey, "Content-Type": "application/json" },
        body: JSON.stringify({ country: opts.country, service: opts.service ?? "wa", maxPrice: opts.maxPrice, operator: opts.operator ?? "0" }),
      },
      directParams
    );

    if (result.source === "server") return result.json;
    const text = result.text;
    if (text.startsWith("ACCESS_NUMBER:")) {
      const parts = text.split(":");
      return { success: true, orderId: parts[1], phone: parts[2] };
    }
    if (text === "NO_NUMBERS") return { success: false, error: "NO_NUMBERS" };
    if (text === "NO_MONEY") return { success: false, error: "NO_MONEY" };
    return { success: false, error: text };
  } catch {
    return { success: false, error: "FETCH_ERROR" };
  }
}

export async function getStatus(apiKey: string, id: string): Promise<{ success: boolean; status?: string }> {
  try {
    const result = await heroRace(
      `/api/status/${id}`,
      { headers: { "x-api-key": apiKey } },
      { api_key: apiKey, action: "getStatus", id }
    );
    if (result.source === "server") return result.json;
    return { success: true, status: result.text };
  } catch {
    return { success: false };
  }
}

export async function cancelNumber(apiKey: string, id: string): Promise<{ success: boolean }> {
  try {
    const result = await heroRace(
      `/api/cancel/${id}`,
      { method: "POST", headers: { "x-api-key": apiKey } },
      { api_key: apiKey, action: "setStatus", id, status: "8" }
    );
    if (result.source === "server") return result.json;
    return { success: true };
  } catch {
    return { success: false };
  }
}
