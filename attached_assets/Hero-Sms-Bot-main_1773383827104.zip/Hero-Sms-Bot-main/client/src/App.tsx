import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import Login from "@/pages/login";
import { getBalance } from "@/lib/heroApi";
import { useEffect, useState } from "react";

function App() {
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    document.documentElement.classList.add("dark");
    const stored = localStorage.getItem("hero_api_key");
    if (!stored) {
      setChecking(false);
      return;
    }
    // Validate stored key on startup — direct browser call, no server proxy
    getBalance(stored)
      .then((json) => {
        if (json.success) {
          setApiKey(stored);
        } else {
          localStorage.removeItem("hero_api_key");
        }
      })
      .catch(() => setApiKey(stored))
      .finally(() => setChecking(false));
  }, []);

  const handleLogin = (key: string) => setApiKey(key);
  const handleLogout = () => setApiKey(null);

  if (checking) {
    return (
      <div className="h-screen bg-[#0a0a0a] flex flex-col items-center justify-center gap-3">
        <div className="w-5 h-5 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-[11px] text-zinc-600 font-mono">Memverifikasi API key...</p>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        {apiKey ? (
          <Home apiKey={apiKey} onLogout={handleLogout} />
        ) : (
          <Login onLogin={handleLogin} />
        )}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
