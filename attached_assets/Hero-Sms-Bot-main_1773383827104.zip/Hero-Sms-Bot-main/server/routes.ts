import type { Express } from "express";
import { createServer, type Server } from "http";
import { execSync } from "child_process";

const BASE_URL = "https://hero-sms.com/stubs/handler_api.php";

function heroRequestCurl(apiKey: string, params: Record<string, string>): string {
  const url = new URL(BASE_URL);
  url.searchParams.set("api_key", apiKey);
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, v);
  }

  const escaped = url.toString().replace(/'/g, "'\\''");
  const cmd =
    `curl -s --max-time 8 --compressed` +
    ` -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'` +
    ` -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'` +
    ` -H 'Accept-Language: en-US,en;q=0.9'` +
    ` -H 'Accept-Encoding: gzip, deflate, br'` +
    ` -H 'Connection: keep-alive'` +
    ` -H 'Cache-Control: no-cache'` +
    ` -H 'Referer: https://hero-sms.com/'` +
    ` -H 'Origin: https://hero-sms.com'` +
    ` '${escaped}'`;

  const text = execSync(cmd, { encoding: "utf-8", timeout: 10000 }).trim();

  if (text.includes("<!DOCTYPE html>") || text.includes("Cloudflare") || text.includes("<html")) {
    throw new Error("CF_BLOCKED");
  }
  return text;
}

function getApiKey(req: any): string | null {
  return (req.headers["x-api-key"] as string) || req.query.api_key || null;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/balance", async (req, res) => {
    const apiKey = getApiKey(req);
    if (!apiKey) return res.status(400).json({ success: false, error: "API key required" });
    try {
      const result = heroRequestCurl(apiKey, { action: "getBalance" });
      if (result.startsWith("ACCESS_BALANCE:")) {
        res.json({ success: true, balance: parseFloat(result.split(":")[1]) });
      } else {
        res.json({ success: false, error: result });
      }
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.get("/api/prices", async (req, res) => {
    const apiKey = getApiKey(req);
    if (!apiKey) return res.status(400).json({ success: false, error: "API key required" });
    const { service = "wa", country } = req.query as Record<string, string>;
    try {
      const result = heroRequestCurl(apiKey, { action: "getPrices", service, country });
      const parsed = JSON.parse(result);
      const serviceData = parsed?.[country]?.[service];
      res.json({ success: true, cost: serviceData?.cost ?? null, count: serviceData?.count ?? 0 });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post("/api/buy", async (req, res) => {
    const apiKey = getApiKey(req);
    if (!apiKey) return res.status(400).json({ success: false, error: "API key required" });
    const country: string = req.body?.country ?? "54";
    const maxPrice: string | undefined = req.body?.maxPrice;
    const operator: string = req.body?.operator ?? "0";
    const service: string = req.body?.service ?? "wa";
    try {
      const params: Record<string, string> = { action: "getNumber", service, country, operator };
      if (maxPrice) params.maxPrice = maxPrice;
      const result = heroRequestCurl(apiKey, params);
      if (result.startsWith("ACCESS_NUMBER:")) {
        const parts = result.split(":");
        res.json({ success: true, orderId: parts[1], phone: parts[2] });
      } else if (result === "NO_NUMBERS") {
        res.json({ success: false, error: "NO_NUMBERS" });
      } else if (result === "NO_MONEY") {
        res.json({ success: false, error: "NO_MONEY" });
      } else {
        res.json({ success: false, error: result });
      }
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.get("/api/status/:id", async (req, res) => {
    const apiKey = getApiKey(req);
    if (!apiKey) return res.status(400).json({ success: false, error: "API key required" });
    try {
      const result = heroRequestCurl(apiKey, { action: "getStatus", id: req.params.id });
      res.json({ success: true, status: result });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post("/api/cancel/:id", async (req, res) => {
    const apiKey = getApiKey(req);
    if (!apiKey) return res.status(400).json({ success: false, error: "API key required" });
    try {
      const result = heroRequestCurl(apiKey, { action: "setStatus", id: req.params.id, status: "8" });
      res.json({ success: true, result });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  return httpServer;
}
